
  # Desain UI Website Pemerintahan

  This is a code bundle for Desain UI Website Pemerintahan. The original project is available at https://www.figma.com/design/hmlmP2EaPRxVYH7eKj3y72/Desain-UI-Website-Pemerintahan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  